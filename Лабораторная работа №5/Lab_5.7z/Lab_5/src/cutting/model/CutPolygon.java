package clippingalgorithms.models;

import javafx.beans.NamedArg;
import javafx.scene.chart.Axis;
import javafx.scene.chart.LineChart;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polygon;

public class PolygonLineChart extends LineChart {

    private Polygon cutPolygon;
    
    private Polygon polygon;
    
    private String color;
    

    
    private boolean isPolygon = false;
    public void setCutPolygon(Polygon cutPolygon) 
    {
        this.cutPolygon = cutPolygon;
    }
    
    public void setPolygon(Polygon polygon)
    {
        this.polygon = polygon;
    }
    @Override
    protected void layoutPlotChildren() {
        super.layoutPlotChildren();
        if (polygon != null) 
        {    
            if(!isPolygon)
            {
                getPlotChildren().removeIf(o -> o instanceof Polygon);      
                isPolygon = true;
            }
            else{
                isPolygon  = false;
            }           
            polygon.toBack();
            polygon.setStrokeWidth(3.0);
            polygon.setStroke(Color.web(color));
            polygon.setFill(Color.TRANSPARENT);
            getPlotChildren().add(polygon);
            polygon = null;
        }
        if (cutPolygon != null)
        {
            if(!isPolygon)
            {
                 getPlotChildren().removeIf(o -> o instanceof Polygon);                
            }
            cutPolygon.toBack();
            
            cutPolygon.setStrokeWidth(3.0);
            
            
            
            
            cutPolygon.setStroke(Color.web("#9A1059"));
            
            cutPolygon.setFill(Color.TRANSPARENT);
            
            getPlotChildren().add(cutPolygon);
            
            cutPolygon = null;
        }     
    }
    public PolygonLineChart(@NamedArg("xAxis") Axis xAxis, @NamedArg("yAxis") Axis yAxis)
    {
        super(xAxis, yAxis);
    }

    
    public void setColor(String color)
    {
        this.color = color;
    }
}